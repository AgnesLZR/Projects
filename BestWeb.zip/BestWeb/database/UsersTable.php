// database/migrations/0001_01_01_000000_create_users_table.php  (reference only)
public function up(): void
{
    Schema::create('users', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('email')->unique();
        $table->string('phone_number')->unique();      // added
        $table->timestamp('email_verified_at')->nullable();
        $table->string('password');
        $table->boolean('status')->default(true);      // added
        $table->rememberToken();
        $table->timestamps();
        $table->softDeletes();                         // added
    });

    Schema::create('password_reset_tokens', function (Blueprint $table) {
        $table->string('email')->primary();
        $table->string('token');
        $table->timestamp('created_at')->nullable();
    });

    Schema::create('sessions', function (Blueprint $table) {
        $table->string('id')->primary();
        $table->foreignId('user_id')->nullable()->index();
        $table->string('ip_address', 45)->nullable();
        $table->text('user_agent')->nullable();
        $table->longText('payload');
        $table->integer('last_activity')->index();
    });
}