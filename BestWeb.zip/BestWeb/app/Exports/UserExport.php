<?php

namespace App\Exports;

use App\Models\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class UsersExport implements FromCollection, WithHeadings, WithMapping
{
    /**
     * Fetch the users data to export.
     */
    public function collection()
    {
        return User::select('id', 'name', 'email', 'phone_number', 'status', 'created_at')->get();
    }

    /**
     * Column headings for the Excel file.
     */
    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Email',
            'Phone Number',
            'Status',
            'Created At',
        ];
    }

    /**
     * Map each row to the columns above.
     */
    public function map($user): array
    {
        return [
            $user->id,
            $user->name,
            $user->email,
            $user->phone_number,
            $user->status ? 'Active' : 'Inactive',
            $user->created_at?->toDateTimeString(),
        ];
    }
}