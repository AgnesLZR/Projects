<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     * Assessment requires public access, so always true.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules for creating a user.
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'phone_number' => ['required', 'string', 'max:20', 'unique:users,phone_number'],
            'password' => ['required', 'string', 'min:8'],
            'status' => ['nullable', 'boolean'],
        ];
    }

    /**
     * Custom validation messages (optional, helps readability).
     */
    public function messages(): array
    {
        return [
            'phone_number.unique' => 'This phone number is already registered.',
            'email.unique' => 'This email address is already registered.',
        ];
    }
}