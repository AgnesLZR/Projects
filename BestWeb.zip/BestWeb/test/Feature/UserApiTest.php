<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserApiTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_can_list_users_with_pagination(): void
    {
        User::factory()->count(15)->create();

        $response = $this->getJson('/api/users');

        $response->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    '*' => ['id', 'name', 'email', 'phone_number', 'status', 'created_at'],
                ],
                'links',
                'meta',
            ])
            ->assertJsonCount(10, 'data'); // 10 per page
    }

    /** @test */
    public function it_can_filter_users_by_status(): void
    {
        User::factory()->count(3)->create(['status' => true]);
        User::factory()->count(2)->create(['status' => false]);

        $response = $this->getJson('/api/users?status=1');

        $response->assertStatus(200)->assertJsonCount(3, 'data');
    }

    /** @test */
    public function it_can_create_a_user(): void
    {
        $payload = [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone_number' => '0123456789',
            'password' => 'password123',
            'status' => true,
        ];

        $response = $this->postJson('/api/users', $payload);

        $response->assertStatus(201)
            ->assertJsonPath('data.email', 'test@example.com');

        $this->assertDatabaseHas('users', ['email' => 'test@example.com']);
    }

    /** @test */
    public function it_fails_validation_on_create_with_duplicate_email(): void
    {
        User::factory()->create(['email' => 'taken@example.com']);

        $response = $this->postJson('/api/users', [
            'name' => 'Another',
            'email' => 'taken@example.com',
            'phone_number' => '0199999999',
            'password' => 'password123',
        ]);

        $response->assertStatus(422)->assertJsonValidationErrors(['email']);
    }

    /** @test */
    public function it_can_show_a_user(): void
    {
        $user = User::factory()->create();

        $this->getJson("/api/users/{$user->id}")
            ->assertStatus(200)
            ->assertJsonPath('data.id', $user->id);
    }

    /** @test */
    public function it_can_update_a_user(): void
    {
        $user = User::factory()->create(['email' => 'old@example.com']);

        $this->putJson("/api/users/{$user->id}", [
            'name' => 'Updated Name',
            'email' => 'new@example.com',
            'phone_number' => $user->phone_number,
        ])->assertStatus(200)
            ->assertJsonPath('data.name', 'Updated Name')
            ->assertJsonPath('data.email', 'new@example.com');
    }

    /** @test */
    public function it_soft_deletes_a_user(): void
    {
        $user = User::factory()->create();

        $this->deleteJson("/api/users/{$user->id}")->assertStatus(200);

        $this->assertSoftDeleted('users', ['id' => $user->id]);
    }

    /** @test */
    public function it_bulk_soft_deletes_users(): void
    {
        $users = User::factory()->count(3)->create();

        $this->postJson('/api/users/bulk-delete', [
            'ids' => $users->pluck('id')->toArray(),
        ])->assertStatus(200);

        foreach ($users as $user) {
            $this->assertSoftDeleted('users', ['id' => $user->id]);
        }
    }

    /** @test */
    public function it_returns_404_for_missing_user(): void
    {
        $this->getJson('/api/users/9999')->assertStatus(404);
    }
}