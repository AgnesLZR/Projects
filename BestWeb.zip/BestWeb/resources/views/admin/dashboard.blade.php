<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>User Management — BestWeb</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5 mb-5">
    <h2 class="mb-4">User Management</h2>

    {{-- Filters and Actions --}}
    <div class="row mb-3 align-items-center">
        <div class="col-md-3">
            <select id="statusFilter" class="form-select" onchange="loadUsers(1)">
                <option value="">All Statuses</option>
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
        </div>
        <div class="col-md-3">
            <a href="/api/users/export/excel" class="btn btn-success w-100">Export to Excel</a>
        </div>
        <div class="col-md-3">
            <button class="btn btn-danger w-100" onclick="bulkDelete()">Bulk Delete Selected</button>
        </div>
        <div class="col-md-3 text-end">
            <button class="btn btn-primary w-100" onclick="showCreateModal()">+ Add User</button>
        </div>
    </div>

    {{-- Users Table --}}
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
            <tr>
                <th style="width:40px;">
                    <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                </th>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Status</th>
                <th style="width:180px;">Actions</th>
            </tr>
            </thead>
            <tbody id="userTableBody">
            <tr><td colspan="7" class="text-center text-muted">Loading...</td></tr>
            </tbody>
        </table>
    </div>

    {{-- Pagination --}}
    <div id="pagination" class="d-flex justify-content-between align-items-center"></div>
</div>

{{-- Create User Modal --}}
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2"><label class="form-label">Name</label><input type="text" id="c_name" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Email</label><input type="email" id="c_email" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Phone</label><input type="text" id="c_phone" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Password</label><input type="password" id="c_password" class="form-control"></div>
                <div class="mb-2">
                    <label class="form-label">Status</label>
                    <select id="c_status" class="form-select">
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <div id="c_error" class="text-danger small"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" onclick="createUser()">Save</button>
            </div>
        </div>
    </div>
</div>

{{-- Edit User Modal --}}
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="e_id">
                <div class="mb-2"><label class="form-label">Name</label><input type="text" id="e_name" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Email</label><input type="email" id="e_email" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Phone</label><input type="text" id="e_phone" class="form-control"></div>
                <div class="mb-2"><label class="form-label">Password (leave blank to keep)</label><input type="password" id="e_password" class="form-control"></div>
                <div class="mb-2">
                    <label class="form-label">Status</label>
                    <select id="e_status" class="form-select">
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
                <div id="e_error" class="text-danger small"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-primary" onclick="updateUser()">Update</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const API_URL = '/api/users';
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    let currentPage = 1;

    const createModal = new bootstrap.Modal(document.getElementById('createModal'));
    const editModal = new bootstrap.Modal(document.getElementById('editModal'));

    // ---------- Load ----------
    async function loadUsers(page = 1) {
        currentPage = page;
        const status = document.getElementById('statusFilter').value;
        let url = `${API_URL}?page=${page}`;
        if (status !== '') url += `&status=${status}`;

        try {
            const response = await fetch(url, {
                headers: { 'Accept': 'application/json' }
            });
            const result = await response.json();
            renderTable(result.data);
            renderPagination(result.meta);
        } catch (e) {
            document.getElementById('userTableBody').innerHTML =
                '<tr><td colspan="7" class="text-center text-danger">Failed to load users.</td></tr>';
        }
    }

    function renderTable(users) {
        const tbody = document.getElementById('userTableBody');
        if (!users.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No users found.</td></tr>';
            return;
        }
        tbody.innerHTML = users.map(u => `
            <tr>
                <td><input type="checkbox" class="row-check" value="${u.id}"></td>
                <td>${u.id}</td>
                <td>${escapeHtml(u.name)}</td>
                <td>${escapeHtml(u.email)}</td>
                <td>${escapeHtml(u.phone_number)}</td>
                <td>
                    <span class="badge ${u.status === 'Active' ? 'bg-success' : 'bg-secondary'}">
                        ${u.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-warning" onclick='openEdit(${JSON.stringify(u)})'>Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser(${u.id})">Delete</button>
                </td>
            </tr>
        `).join('');
    }

    function renderPagination(meta) {
        document.getElementById('pagination').innerHTML = `
            <div>Showing page <strong>${meta.current_page}</strong> of <strong>${meta.last_page}</strong> — total ${meta.total} users</div>
            <div>
                <button class="btn btn-secondary btn-sm" onclick="loadUsers(${meta.current_page - 1})"
                        ${meta.current_page === 1 ? 'disabled' : ''}>Prev</button>
                <button class="btn btn-secondary btn-sm" onclick="loadUsers(${meta.current_page + 1})"
                        ${meta.current_page === meta.last_page ? 'disabled' : ''}>Next</button>
            </div>
        `;
    }

    // ---------- Create ----------
    function showCreateModal() {
        document.getElementById('c_name').value = '';
        document.getElementById('c_email').value = '';
        document.getElementById('c_phone').value = '';
        document.getElementById('c_password').value = '';
        document.getElementById('c_status').value = '1';
        document.getElementById('c_error').textContent = '';
        createModal.show();
    }

    async function createUser() {
        const payload = {
            name: document.getElementById('c_name').value,
            email: document.getElementById('c_email').value,
            phone_number: document.getElementById('c_phone').value,
            password: document.getElementById('c_password').value,
            status: document.getElementById('c_status').value === '1',
        };

        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
            },
            body: JSON.stringify(payload),
        });

        if (response.ok) {
            createModal.hide();
            loadUsers(currentPage);
        } else {
            const err = await response.json();
            document.getElementById('c_error').textContent = flattenErrors(err);
        }
    }

    // ---------- Edit ----------
    function openEdit(user) {
        document.getElementById('e_id').value = user.id;
        document.getElementById('e_name').value = user.name;
        document.getElementById('e_email').value = user.email;
        document.getElementById('e_phone').value = user.phone_number;
        document.getElementById('e_password').value = '';
        document.getElementById('e_status').value = user.status === 'Active' ? '1' : '0';
        document.getElementById('e_error').textContent = '';
        editModal.show();
    }

    async function updateUser() {
        const id = document.getElementById('e_id').value;
        const payload = {
            name: document.getElementById('e_name').value,
            email: document.getElementById('e_email').value,
            phone_number: document.getElementById('e_phone').value,
            status: document.getElementById('e_status').value === '1',
        };
        const password = document.getElementById('e_password').value;
        if (password) payload.password = password;

        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
            },
            body: JSON.stringify(payload),
        });

        if (response.ok) {
            editModal.hide();
            loadUsers(currentPage);
        } else {
            const err = await response.json();
            document.getElementById('e_error').textContent = flattenErrors(err);
        }
    }

    // ---------- Delete ----------
    async function deleteUser(id) {
        if (!confirm('Soft delete this user?')) return;
        await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
            headers: { 'Accept': 'application/json', 'X-CSRF-TOKEN': csrfToken },
        });
        loadUsers(currentPage);
    }

    // ---------- Bulk Delete ----------
    function toggleSelectAll(box) {
        document.querySelectorAll('.row-check').forEach(c => c.checked = box.checked);
    }

    async function bulkDelete() {
        const ids = Array.from(document.querySelectorAll('.row-check:checked')).map(c => parseInt(c.value));
        if (!ids.length) {
            alert('Select at least one user.');
            return;
        }
        if (!confirm(`Soft delete ${ids.length} selected user(s)?`)) return;

        await fetch(`${API_URL}/bulk-delete`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
            },
            body: JSON.stringify({ ids }),
        });
        loadUsers(currentPage);
    }

    // ---------- Utils ----------
    function flattenErrors(obj) {
        if (!obj.errors) return obj.message || 'An error occurred.';
        return Object.values(obj.errors).flat().join(' ');
    }

    function escapeHtml(str) {
        if (str == null) return '';
        return String(str)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    }

    // ---------- Init ----------
    loadUsers();
</script>
</body>
</html>