<?php

use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
| In Laravel 11, api.php is only loaded if you run:
|   php artisan install:api
| See Step 2 of the README for instructions.
*/

Route::get('users/export/excel', [UserController::class, 'export']);
Route::post('users/bulk-delete', [UserController::class, 'bulkDelete']);

Route::apiResource('users', UserController::class);